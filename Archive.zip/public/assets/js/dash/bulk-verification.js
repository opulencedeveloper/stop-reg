document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector(".bulk-verification-form");
  const submitBtn = form.querySelector(".bulk-verify-domain-btn");

  const token = localStorage.getItem("authToken");

  const bulkLinks = document.getElementById("bulk-links");
  const disposableResult = document.getElementById("disposableResult");
  const downloadBtn = document.getElementById("bulk-domain-download");

  if (downloadBtn) downloadBtn.classList.add("hidden"); // hide by default

  // Support for dashboard spinner architecture
  // Since this page doesn't fetch data on load, but others might be loading,
  // we just call hideSpinner() to signal we're ready.
  if (typeof window.hideSpinner === 'function') {
    window.hideSpinner();
  }

  // Store the API response data for CSV download and pagination
  let storedResponseData = [];
  let currentPage = 1;
  let rowsPerPage = 6;
  let totalPages = 1;
  let totalDocs = 0;
  let currentSearchFilter = '';
  let currentDomainSearch = '';
  let domainSearchTimeout;
  let filteredResults = [];

  // --- Search Handler with Dropdown (Read-only) ---
  const searchInput = document.getElementById('bulk-verification-search-input');
  const dropdown = document.getElementById('bulk-verification-dropdown');

  if (searchInput && dropdown) {
    // Show dropdown on focus or click
    const showDropdown = () => dropdown.classList.add('active');
    searchInput.addEventListener('focus', showDropdown);
    searchInput.addEventListener('click', showDropdown);

    // Handle dropdown item selection only
    dropdown.querySelectorAll('.dropdown-item').forEach(item => {
      item.addEventListener('click', () => {
        const value = item.getAttribute('data-value');
        const label = item.textContent;
        searchInput.value = label;
        currentSearchFilter = value;
        currentPage = 1;
        dropdown.classList.remove('active');
        renderTablePage();
      });
    });

    // Close dropdown when clicking outside (not on blur to avoid flicker)
    document.addEventListener('click', (e) => {
      if (!searchInput.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('active');
      }
    });
  }

  // --- Domain/Provider Search Handler with Debouncing ---
  const domainSearchInput = document.getElementById('bulk-verification-domain-search-input');
  if (domainSearchInput) {
    domainSearchInput.addEventListener('input', (e) => {
      currentDomainSearch = e.target.value.toLowerCase();
      currentPage = 1;

      // Debounce rendering (500ms delay)
      clearTimeout(domainSearchTimeout);
      domainSearchTimeout = setTimeout(() => {
        renderTablePage();
      }, 500);
    });
  }

  function renderEmptyState() {
    if (!disposableResult) return;
    disposableResult.innerHTML = "";

    const tr = document.createElement("tr");
    tr.className = "empty-state-row"; // Changed class slightly to distinguish

    const td = document.createElement("td");
    td.colSpan = 12; // Span all 12 table columns
    td.style.height = "400px";
    td.style.padding = "0";
    td.style.textAlign = "center";
    td.style.verticalAlign = "middle";

    td.innerHTML = `
        <div style="display: inline-flex; flex-direction: column; align-items: center; justify-content: center; height: 100%;">
            <div class="empty-state-icon-wrapper">
                <img src="/assets/icons/search-status.svg" alt="No Results" onerror="this.src='/assets/icons/empty.svg'" />
            </div>
            <h3 class="empty-state-text">Ready to Verify</h3>
            <p class="empty-state-subtext">Enter your list of domains or emails above and click Start Verification to see results.</p>
        </div>
    `;

    tr.appendChild(td);
    disposableResult.appendChild(tr);

    if (downloadBtn) downloadBtn.classList.add("hidden");
    
    // Hide pagination controls if empty
    const paginationContainer = document.querySelector('.table-pagination');
    if(paginationContainer) paginationContainer.style.display = 'none';
  }

  renderEmptyState(); // Show animated empty state by default

  // Function to extract domain from URL
  function extractDomain(input) {
    let cleaned = input.trim();
    cleaned = cleaned.replace(/^https?:\/\//i, '');
    cleaned = cleaned.replace(/^ftp:\/\//i, '');
    cleaned = cleaned.replace(/^www\./i, '');
    cleaned = cleaned.split('/')[0];
    cleaned = cleaned.split(':')[0];
    cleaned = cleaned.split('?')[0];
    cleaned = cleaned.split('#')[0];
    return cleaned.trim();
  }

  // Validation function for email and domain
  function isValidEmailOrDomain(input) {
    const trimmed = input.trim();
    if (!trimmed) return false;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const domainPattern = /^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    if (emailPattern.test(trimmed)) return true;
    const extractedDomain = extractDomain(trimmed);
    if (extractedDomain && extractedDomain.length > 0 && domainPattern.test(extractedDomain)) return true;
    if (domainPattern.test(trimmed)) return true;
    return false;
  }

  // Format textarea content - put each item on a new line
  function formatTextarea() {
    if (!bulkLinks) return;
    const text = bulkLinks.value;
    if (!text) return;

    const items = text.split(/[\s,\n]+/).filter((v) => v.trim() !== "");
    const formattedItems = [];
    const invalidItems = [];

    items.forEach((item) => {
      const trimmed = item.trim();
      if (trimmed && isValidEmailOrDomain(trimmed)) {
        const cleaned = trimmed.includes('@') ? trimmed : extractDomain(trimmed);
        formattedItems.push(cleaned);
      } else if (trimmed) {
        invalidItems.push(trimmed);
      }
    });

    if (invalidItems.length > 0) {
      const errorMessage = `Invalid email/domain: ${invalidItems.join(", ")}`;
      if (typeof iziToast !== 'undefined') {
        iziToast.warning({
          title: 'Invalid Input',
          message: errorMessage,
          position: "topRight",
          timeout: 5000,
        });
      }
    }

    if (formattedItems.length > 0) {
      bulkLinks.value = formattedItems.join('\n');
    }
  }

  if (bulkLinks) {
    let lastValue = '';
    // Intercept Space key to create new line
    bulkLinks.addEventListener("keydown", (e) => {
      if (e.key === ' ') {
        e.preventDefault();
        // Insert newline at cursor and move cursor after it
        bulkLinks.setRangeText('\n', bulkLinks.selectionStart, bulkLinks.selectionEnd, 'end');
      }
    });

    // Remove the previous complicated input listener
    // bulkLinks.addEventListener("input", (e) => { ... });

    bulkLinks.addEventListener("paste", (e) => {
      setTimeout(() => {
        formatTextarea();
        bulkLinks.setSelectionRange(bulkLinks.value.length, bulkLinks.value.length);
      }, 10);
    });
  }

  function getLinksArray() {
    if (!bulkLinks) return [];
    const text = bulkLinks.value.trim();
    if (!text) return [];
    const items = text.split(/[\n\s,]+/).filter((v) => v.trim() !== "");
    const links = [];
    items.forEach((item) => {
      const trimmed = item.trim();
      if (trimmed && isValidEmailOrDomain(trimmed)) {
        const cleaned = trimmed.includes('@') ? trimmed : extractDomain(trimmed);
        if (cleaned) links.push(cleaned);
      }
    });
    return [...new Set(links)];
  }

  // --- Helper: Get classification from item (handles both nested dbEntry and root level) ---
  function getClassification(item) {
    return item.classification || (item.dbEntry && item.dbEntry.classification) || null;
  }

  // --- Helper: Map Classification Enum to Display Value ---
  function mapClassificationToDisplay(classification) {
      if (!classification) return '-';

      const classificationMap = {
          'disposable_address': 'disposable',
          'undeliverable_domain': 'private',
          'email_alias_native': 'alias:native',
          'email_alias_forwarding': 'alias:forwarding',
          'role_account': 'role',
          'free_subdomain_provider': 'free subdomain',
          'email_edu': 'edu',
          'email_isp': 'isp',
          'email_routing': 'relay',
          'private_domain': 'private',
          'public_mailbox_provider': 'public',
          'allowlisted_domain': 'allowlisted',
          'blocklisted_domain': 'blocklisted'
      };

      return classificationMap[classification] || '-';
  }

  function renderTablePage() {
    if (!disposableResult) return;
    disposableResult.innerHTML = "";

    if (storedResponseData.length === 0) {
      renderEmptyState();
      return;
    }

    // Filter by classification and/or domain/provider
    filteredResults = storedResponseData;

    if (currentSearchFilter) {
      filteredResults = filteredResults.filter(item => {
        const classification = mapClassificationToDisplay(getClassification(item)).toLowerCase();
        return classification.includes(currentSearchFilter);
      });
    }

    if (currentDomainSearch) {
      filteredResults = filteredResults.filter(item => {
        const domain = (item.domain || '').toLowerCase();
        const provider = (item.provider || '').toLowerCase();
        return domain.includes(currentDomainSearch) || provider.includes(currentDomainSearch);
      });
    }

    if (filteredResults.length === 0) {
      disposableResult.innerHTML = `
        <tr>
          <td colspan="10" style="text-align: center; padding: 40px; color: #667085;">
            No results found for "${currentSearchFilter}"
          </td>
        </tr>
      `;
      return;
    }

    const paginationContainer = document.querySelector('.table-pagination');
    if (paginationContainer) paginationContainer.style.display = totalPages > 1 ? '' : 'none';

    if (downloadBtn) downloadBtn.classList.remove("hidden");

    const startIndex = (currentPage - 1) * rowsPerPage;

    const formatValue = (val) => {
        if (val === true) return `<div class="status-badge status-bool-yes"><span>Yes</span></div>`;
        if (val === false) return '-';
        return val || '-';
    };

    filteredResults.forEach((item, index) => {
        const tr = document.createElement("tr");
        const domain = item.domain || '-';
        const isRole = formatValue(item.isRoleDomain);
        const isAlias = formatValue(item.isAliasDomain);
        const isProvider = item.provider || '-';
        const isMx = formatValue(item.hasMxRecords);
        const date = item.updatedAt ? new Date(item.updatedAt).toLocaleDateString() : '-';
        const unresolvedVal = (item.unresolved || 0);
        const isUnresolvedBool = unresolvedVal > 0;
        const isUnresolved = isUnresolvedBool
            ? `<div class="status-badge status-unresolved-yes"><span>Yes</span></div>`
            : '-';

        // Classification: Map enum to display value
        const classificationDisplay = mapClassificationToDisplay(getClassification(item));
        const classificationHtml = classificationDisplay === '-'
            ? '<span style="color: #667085; font-size: 14px;">-</span>'
            : `<span style="color: #404040; font-size: 14px;">${classificationDisplay}</span>`;

        // Blocklisted: Use red theme for "Yes"
        const isBlocklistedBool = item.blocklisted === true;
        const blocklistedBadge = isBlocklistedBool
            ? `<span class="status-blocklisted-yes"><span>Yes</span></span>`
            : '-';

        tr.innerHTML = `
          <td style="text-align: center;">${startIndex + index + 1}</td>
          <td>${domain}</td>
          <td>${isProvider}</td>
          <td>${classificationHtml}</td>
          <td>${isRole}</td>
          <td>${isAlias}</td>
          <td>${blocklistedBadge}</td>
          <td>${isMx}</td>
          <td>${date}</td>
        `;
        disposableResult.appendChild(tr);
    });

    renderPaginationControls();
  }

  // Fetch Requests on Load
  const fetchRequests = async (page = 1) => {
    currentPage = page;

    if (disposableResult) {
        disposableResult.innerHTML = `
            <tr>
                <td colspan="10" style="text-align: center; padding: 40px;">
                    <div class="stopreg-spinner" style="border-top-color: #1452CA; border-right-color: #1452CA; margin: 0 auto;"></div>
                </td>
            </tr>
        `;
    }
    const paginationContainer = document.querySelector('.table-pagination');
    if (paginationContainer) paginationContainer.style.display = 'none';

    try {
        const response = await fetch(
            `https://api.stopreg.com/api/v1/user/info/requests?last30Days=true&page=${page}&limit=${rowsPerPage}&requestType=bulk`,
            { headers: { 'Authorization': `Bearer ${token}` } }
        );
        const result = await response.json();

        if (await window.handleAuthError(response)) return;

        if (result.message === "success" && result.data && result.data.docs) {
            console.log("[Bulk Verification] API Response - Success:", result);
            console.log("[Bulk Verification] Data received:", {
                docsCount: result.data.docs?.length || 0,
                totalPages: result.data.meta?.totalPages,
                totalDocs: result.data.meta?.totalDocs,
                hasSearch: currentSearchFilter ? true : false
            });
            storedResponseData = result.data.docs;
            totalPages = result.data.meta.totalPages || 1;
            totalDocs = result.data.meta.totalDocs || 0;
            renderTablePage();
        } else {
            throw new Error(result.message || "Failed to load requests");
        }
    } catch (error) {
        console.error("[Bulk Verification] Error fetching requests:", error);
        console.log("[Bulk Verification] Full error object:", {
            message: error.message,
            status: error.status,
            statusText: error.statusText,
            response: error.response,
            stack: error.stack
        });
        if (window.handleAuthError && await window.handleAuthError(error)) return;
        if (disposableResult) {
            console.log("[Bulk Verification] Rendering error state UI");
            disposableResult.innerHTML = `
                <tr>
                    <td colspan="9">
                        <div class="fetch-error-state">
                            <div class="error-icon-wrapper">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                </svg>
                            </div>
                            <h3 class="error-title">Failed to load data</h3>
                            <p class="error-desc">Something went wrong. Please try again.</p>
                            <button class="retry-btn">Try Again</button>
                        </div>
                    </td>
                </tr>
            `;
            const retryBtn = disposableResult.querySelector('.retry-btn');
            if (retryBtn) {
                console.log("[Bulk Verification] Retry button attached");
                retryBtn.onclick = () => {
                    console.log("[Bulk Verification] Retry button clicked - refetching data from API");
                    fetchRequests(currentPage);
                };
            }
        }
    }
  };

  fetchRequests(1);

  function renderPaginationControls() {
      const controlsDiv = document.querySelector('.pagination-controls');
      if (!controlsDiv) return;

      const prev = controlsDiv.querySelector('.prev-btn');
      const next = controlsDiv.querySelector('.next-btn');

      if (prev) prev.disabled = currentPage === 1;
      if (next) next.disabled = currentPage === totalPages || totalPages === 0;

      controlsDiv.innerHTML = '';
      if (prev) controlsDiv.appendChild(prev);

      const addPageBtn = (pageNum) => {
          const btn = document.createElement('button');
          btn.className = `page-number ${pageNum === currentPage ? 'active' : ''}`;
          btn.textContent = pageNum;
          btn.addEventListener('click', () => fetchRequests(pageNum));
          controlsDiv.appendChild(btn);
      };

      const addDots = () => {
          const span = document.createElement('span');
          span.className = 'page-dots';
          span.textContent = '...';
          controlsDiv.appendChild(span);
      };

      if (totalPages <= 7) {
          for (let i = 1; i <= totalPages; i++) addPageBtn(i);
      } else {
          addPageBtn(1);
          if (currentPage > 3) addDots();

          const start = Math.max(2, currentPage - 1);
          const end = Math.min(totalPages - 1, currentPage + 1);
          for (let i = start; i <= end; i++) addPageBtn(i);

          if (currentPage < totalPages - 2) addDots();
          addPageBtn(totalPages);
      }

      if (next) controlsDiv.appendChild(next);
  }

  // Setup Pagination Event Listeners (Once)
  const paginationSelect = document.querySelector('.pagination-select');
  if (paginationSelect) {
      paginationSelect.addEventListener('change', (e) => {
          const val = parseInt(e.target.value);
          if (!isNaN(val)) {
              rowsPerPage = val;
              fetchRequests(1);
          }
      });
  }

  const prevBtn = document.querySelector('.prev-btn');
  if (prevBtn) {
      prevBtn.addEventListener('click', () => {
          if (currentPage > 1) fetchRequests(currentPage - 1);
      });
  }

  const nextBtn = document.querySelector('.next-btn');
  if (nextBtn) {
      nextBtn.addEventListener('click', () => {
          if (currentPage < totalPages) fetchRequests(currentPage + 1);
      });
  }

  function populateTable(disposal) {
    if (!disposableResult) return;
    disposableResult.innerHTML = "";
    if (!disposal || disposal.length === 0) {
      renderEmptyState();
      storedResponseData = [];
      return;
    }
    storedResponseData = disposal;
    currentPage = 1;

    renderTablePage();
   
    if (downloadBtn) downloadBtn.classList.remove("hidden");
  }

  async function downloadTableData() {
    if (storedResponseData.length === 0) return;
    
    // Send full request history to backend for CSV generation
    const requests = storedResponseData; 
    const originalText = downloadBtn.innerHTML; 
    downloadBtn.disabled = true;
    downloadBtn.innerHTML = `<span class="stopreg-btn-spinner"></span> Downloading...`;

    try {
        const response = await fetch("https://api.stopreg.com/api/v1/email-domains/bulk-verification-csv", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ requests }),
        });

        if (response.ok) {
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = "bulk-verification-results.csv";
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } else {
            if (await window.handleAuthError(response)) {
                return;
            }
            const data = await response.json().catch(() => ({}));
            const errorMessage = data.description || data.message || "Download failed!";
            if (typeof iziToast !== 'undefined') {
                iziToast.error({ title: 'Error', message: errorMessage, position: "topRight" });
            }
        }
    } catch (err) {
        console.error(err);
        if (window.handleAuthError && await window.handleAuthError(err)) {
            return;
        }
        if (typeof iziToast !== 'undefined') {
            iziToast.error({ title: 'Network Error', message: "Failed to download CSV.", position: "topRight" });
        }
    } finally {
        downloadBtn.disabled = false;
        downloadBtn.innerHTML = originalText;
    }
  }

  if (downloadBtn) downloadBtn.addEventListener("click", downloadTableData);

  // Lock Bulk Verification for Premium Users Only
  document.addEventListener("planLoaded", (e) => {
    const planName = e.detail;
    if (planName === "Free") {
        if (form) {
            form.innerHTML = `
               <div style="text-align:center; padding: 40px 20px; background: #f9f9fa; border-radius: 8px; border: 1px solid #e0e0e0; margin-top: 15px;">
                   <div style="margin-bottom: 16px;">
                       <img src="/assets/icons/bi_stars.svg" alt="Premium Feature" style="width: 48px; height: 48px; border-radius: 50%; background: #e8eefa; padding: 10px;">
                   </div>
                   <h3 style="color: #1A1D1F; font-size: 20px; font-weight: 700; margin-bottom: 12px;">Premium Feature</h3>
                   <p style="color: #6F767E; font-size: 15px; margin-bottom: 24px;">Bulk Verification is only available on premium plans. Upgrade your account to verify up to 10,000 domains at once.</p>
                   <a href="/dashboard/payments.html" class="bulk-verify-domain-btn" style="text-decoration:none; display:inline-flex; align-items:center; justify-content:center; max-width: 200px; margin: 0 auto;">Upgrade Now</a>
               </div>
            `;
        }
        
        // Hide history table to emphasize locked state
        if (document.querySelector(".dash-inner-inner-verification-status")) {
            document.querySelector(".dash-inner-inner-verification-status").style.display = "none";
        }
        
        // Hide Download Button
        if (downloadBtn) downloadBtn.classList.add("hidden");
    }
  });

  if (form) {
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      console.log("[Bulk Verification] ========== FORM SUBMITTED ==========");
      const links = getLinksArray();
      console.log("[Bulk Verification] Domains to verify:", links);
      console.log("[Bulk Verification] Total domains:", links.length);

      if (links.length === 0) {
        if (typeof iziToast !== 'undefined') {
          iziToast.warning({
            title: 'Warning',
            message: "Please enter at least one domain or email address.",
            position: "topRight",
          });
        }
        return;
      }
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<span class="stopreg-btn-spinner"></span> Verifying...`;
      try {
        const payload = { emailDomains: links };
        console.log("[Bulk Verification] ========== SENDING REQUEST ==========");
        console.log("[Bulk Verification] Endpoint: POST /api/v1/email-domains/bulk-verification");
        console.log("[Bulk Verification] Payload:", JSON.stringify(payload, null, 2));

        const response = await fetch("https://api.stopreg.com/api/v1/email-domains/bulk-verification", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify(payload),
        });

        const data = await response.json();
        console.log("[Bulk Verification] ========== RESPONSE RECEIVED ==========");
        console.log("[Bulk Verification] Status:", response.status, response.statusText);
        console.log("[Bulk Verification] Response Data:", data);
        console.log("[Bulk Verification] Documents received:", data.data?.length || 0);

        // Log classification values
        if (data.data && Array.isArray(data.data)) {
          console.log("[Bulk Verification] Classification values:");
          data.data.forEach((doc, idx) => {
            console.log(`  ${idx + 1}. ${doc.domain}: classification=${doc.classification}`);
          });
        }

        if (response.ok) {
          console.log("[Bulk Verification] Verification successful!");
          // Display bulk verification results in submitted order (NO race condition)
          storedResponseData = data.data || [];
          totalPages = 1;
          totalDocs = storedResponseData.length;
          currentPage = 1;
          rowsPerPage = 100;
          renderTablePage();

          bulkLinks.value = "";
          if (typeof iziToast !== 'undefined') {
            iziToast.success({
              title: 'Success',
              message: "Bulk verification completed successfully!",
              position: "topRight",
            });
          }

          // Refetch updated database after showing current results
          // (Backend now saves in correct order - no race condition)
          setTimeout(() => fetchRequests(), 100);
        } else {
          console.log("[Bulk Verification] ========== ERROR RESPONSE ==========");
          console.log("[Bulk Verification] ❌ Verification failed!");
          console.log("[Bulk Verification] Status Code:", response.status);
          console.log("[Bulk Verification] Status Text:", response.statusText);
          console.log("[Bulk Verification] Full Error Response:", data);
          console.log("[Bulk Verification] Error Message:", data.message);
          console.log("[Bulk Verification] Error Description:", data.description);
          console.log("[Bulk Verification] Error Details:", JSON.stringify(data, null, 2));

          if (await window.handleAuthError(response)) {
            return;
          }
          const errorMessage = data.description || data.message || "Verification failed!";
          if (typeof iziToast !== 'undefined') {
            iziToast.error({ title: 'Error', message: errorMessage, position: "topRight" });
          }
        }
      } catch (err) {
        console.log("[Bulk Verification] ========== CATCH ERROR ==========");
        console.error("[Bulk Verification] ❌ Network/Exception error:", err);
        console.log("[Bulk Verification] Error name:", err.name);
        console.log("[Bulk Verification] Error message:", err.message);
        console.log("[Bulk Verification] Error cause:", err.cause);
        console.log("[Bulk Verification] Full error stack:", err.stack);
        console.log("[Bulk Verification] Error object:", JSON.stringify(err, null, 2));

        if (window.handleAuthError && await window.handleAuthError(err)) {
          return;
        }
        if (typeof iziToast !== 'undefined') {
          iziToast.error({ title: 'Network Error', message: "Network error,  please try again later.", position: "topRight" });
        }
      } finally {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    });
  }
});

